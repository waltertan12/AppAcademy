# w1d5: [TicTacToe AI][description]

[description]: https://github.com/appacademy/ruby-curriculum/blob/master/projects/w1d5-tic-tac-toe-ai.md
